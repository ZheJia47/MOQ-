require('dotenv').load()
var express = require('express')
var moment = require('moment')
var path = require('path')
var fs = require('fs')
// var util = require('util')
var formidable = require('formidable')
var morgan = require('morgan')
var bodyParser = require('body-parser')
// var jwt = require('jsonwebtoken')
// var expressJwt = require('express-jwt')
// var mongoose = require('mongoose')
// mongoose.connect('mongodb://localhost/vuelogin')
// var User = require('./models')
var MongoClient = require('mongodb').MongoClient
var ObjectID = require('mongodb').ObjectID
var config = require('./index.js')
var opcodes = require('./opcodes.js')
var io = require('socket.io')
var app = express()
var http = require('http')
var server = http.createServer(app)

app.set('port', process.env.PORT || 3000)

app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(morgan('dev'))
app.all('*', function (req, res, next) {
  // res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Origin', 'http://localhost:8080')
  res.header('Access-Control-Allow-Headers', 'X-Requested-With')
  res.header('Access-Control-Allow-Methods', 'POST,GET')
  res.header('Access-Control-Allow-Credentials', true)
  res.header('X-Powered-By', ' 3.2.1')
  res.header('Content-Type', 'application/json;charset=utf-8')
  next()
})
app.get('/api/testDateTime', function (req, res) {
  console.log('1')
  MongoClient.connect(config.dbUrl, function(err, client) {
    console.log('2')
    var m = moment(moment('2018-06-16 12:00:00', 'YYYY-MM-DD HH:mm:ss').add(2,'hours')).toDate()
    console.log(m)
    client.db('timeTest').collection('momentToDate').find({'Now':  { $gt: m }}).toArray(function (err, docs) {
      console.log('3')
      docs.forEach(doc => {
        console.log('5')
        console.log(doc)
        console.log(moment(doc['Now']).format('YYYY/MM/DD HH:mm:ss'))
      })
      console.log('4')
      res.send({
        type: true,
        data: docs
      });
    })
  })
})
/*
var auth = expressJwt({ secret: process.env.JWT_SECRET });

app.post('/api/login', function(req, res) {
  User.findOne({name: req.body.name, password: req.body.password}, function(err, user) {
    if (err) {
      res.send({
        type: false,
        data: "Error occured: " + err
      });
    } else {
      if (user) {
        var expiry = new Date();
        expiry.setDate(expiry.getDate() + 7);
        var token = jwt.sign({
          _id: user._id,
          email: user.email,
          name: user.name,
          exp:parseInt(expiry.getTime()/1000)
        },process.env.JWT_SECRET);
        res.send({
          type: true,
          data: user,
          token: token
        });
      } else {
        res.send({
          type: false,
          data: "用戶未註冊"
        });
      }
    }
  });
});

app.post('/api/logout',auth, function(req, res) {
  res.send({
    type: "1"
  })
});

app.post('/api/reg', function(req, res) {
  User.findOne({name: req.body.name, password: req.body.password}, function(err, user) {
    if (err) {
      res.send({
        type: false,
        data: "Error occured: " + err
      });
    } else {
      if (user) {
        res.send({
          type: false,
          data: "用戶已註冊"
        });
      } else {
        var userModel = new User();
        userModel.name = req.body.name;
        userModel.password = req.body.password;
        userModel.save(function(err, user) {
          user.save(function(err, user1) {
            var expiry = new Date();
            expiry.setDate(expiry.getDate() + 7);
            var token = jwt.sign({
              _id: user._id,
              email: user.email,
              name: user.name,
              exp:parseInt(expiry.getTime()/1000)
            },process.env.JWT_SECRET);
            res.send({
              type: true,
              data: user,
              token: token
            });
          });
        })
      }
    }
  });
});

app.use(function(err, req, res, next) {
  if (err.name == 'UnauthorizedError') {
    res.status(401);
    res.send({ message: err.name + ":" + err.message });
  }
});
*/
app.get('/api/getDetectiveData/:from/:to', function (req, res) {
  var fromRecv = req.params.from
  var toRecv = req.params.to
  var monthCnt = moment(toRecv).diff(moment(fromRecv), 'M') + 1
  var from = moment(moment(fromRecv).date(1).format('YYYY-M-D 00:00:00')).toDate()
  var to = moment(moment(toRecv).add(1, 'month').date(0).format('YYYY-M-D 23:59:59')).toDate()
  console.log(from)
  console.log(to)
  // var from = moment(moment(reportDate).format('YYYY-MM-DD')).toDate()
  // var to = moment(moment(reportDate).format('YYYY-MM-DD 23:59:59')).toDate()
  var idx = 0
  var machines = {}
  MongoClient.connect(config.dbUrl, function(err, client) {
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      var promises = []
      var docs = ['1A01', '1A02', '1A03', '1A04', '1A05', '1A06', '1A07', '1A08','1A09']
        docs.forEach(doc => {
          var machineID = doc
          promises.push(getEachMachineRecords1(client.db(config.dbName), machineID, from, to).then(results => {
            machines[machineID] = results
          }))
        })
      retArray = []
      var nameInfoStr = [{key: 'arm', value: '機械手警報次數'},
        {key: 'machine', value: '成型機警報次數'},
        {key: 'change', value: '換模次數'},
        {key: 'produce', value: '生產模次'},
        {key: 'pred', value: '應產數量'},
        {key: 'safe', value: '入庫數量'},
        {key: 'bad', value: '不良數量'},
        {key: 'defective', value: '平均不良率'}
      ]
      Promise.all(promises).then(() => {
        docs.forEach(doc => {
          nameInfoStr.forEach(nameInfo => {
            retArray.splice(retArray.length, 0, {
              department: '成型一課',
              zone: '1A區',
              machineID: doc,
              nameInfo: nameInfo.value
            })
            var obj = {}
            for (var ind = 0; ind < monthCnt; ind++) {
              machines[doc].forEach(elm => {
                var mCnt = -1
                var trigTime = elm.trigTime || ''
                if (trigTime !== '') {
                  mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                }
                var orderNumber = elm.orderNumber || ''
                if ((mCnt === ind) && (orderNumber !== '')) {
                  if (!obj.hasOwnProperty(orderNumber)) {
                    obj[orderNumber] = elm
                  }
                }
              })
              objArray = Object.keys(obj).map(i => obj[i])
              if (doc === '1A04') {
                console.log(objArray)
              }
              switch (nameInfo.key) {
                case nameInfoStr[0].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    return item.note === '機械手故障'
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc++
                  }, 0))
                  break
                case nameInfoStr[1].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    return item.note === '成型機故障'
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc++
                  }, 0))
                  break
                case nameInfoStr[2].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    return item.note === '更換模具、模仁'
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc++
                  }, 0))
                  break
                case nameInfoStr[3].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    var mCnt = -1
                    var trigTime = item.trigTime || ''
                    if (trigTime !== '') {
                      mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                    }
                    return ((item.machineStatusType === '全自動') || (item.machineStatusType === '半自動')) && (item.orderNumber !== '') && (mCnt === ind)
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc + curr.moldCount
                  }, 0))
                  break
                case nameInfoStr[4].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    var mCnt = -1
                    var trigTime = item.trigTime || ''
                    if (trigTime !== '') {
                      mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                    }
                    return ((item.machineStatusType === '全自動') || (item.machineStatusType === '半自動')) && (item.orderNumber !== '') && (mCnt === ind)
                  }).reduce(function(acc, curr, currIndex, arr) {
                    var cavities = acc.cavities + 0
                    return acc + curr.moldCount * parseInt(cavities)
                  }, 0) + 0) || 0
                  break
                case nameInfoStr[5].key:
                  retArray[retArray.length - 1][ind.toString()] = (objArray.reduce(function(acc, curr, currIndex, arr) {
                    var warehousing = curr.warehousing 
                  return acc + warehousing
                  }, 0))
                  break
                case nameInfoStr[6].key:
                  retArray[retArray.length - 1][ind.toString()] = (machines[doc].filter(function(item, index, array) {
                    var mCnt = -1
                    var trigTime = item.trigTime || ''
                    if (trigTime !== '') {
                      mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                    }
                    return ((item.machineStatusType === '全自動') || (item.machineStatusType === '半自動')) && (item.orderNumber !== '') && (mCnt === ind)
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc + curr.badNum
                  }, 0))
                  break
                case nameInfoStr[7].key:
                  retArray[retArray.length - 1][ind.toString()] = (((machines[doc].filter(function(item, index, array) {
                    var mCnt = -1
                    var trigTime = item.trigTime || ''
                    if (trigTime !== '') {
                      mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                    }
                    return ((item.machineStatusType === '全自動') || (item.machineStatusType === '半自動')) && (item.orderNumber !== '') && (mCnt === ind)
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc + curr.badNum
                  }, 0))) / (machines[doc].filter(function(item, index, array) {
                    var mCnt = -1
                    var trigTime = item.trigTime || ''
                    if (trigTime !== '') {
                      mCnt = moment(trigTime).diff(moment(fromRecv), 'M')
                    }
                    return ((item.machineStatusType === '全自動') || (item.machineStatusType === '半自動')) && (item.orderNumber !== '') && (mCnt === ind)
                  }).reduce(function(acc, curr, currIndex, arr) {
                    return acc + curr.moldCount * parseInt(acc.cavities)
                  }, 0)) + 0) || 0
                  break
              }
            }
          })
        })
        res.send({
          type: true,
          data: retArray
        })
      })
    }
  })
})
function getEachMachineRecords1 (db, machineID, from, to) {
  return new Promise((resolve, reject) => {
    var records = []
    var col = db.collection(machineID)
    // console.log(machineID)
    // console.log([db, machineID, from, to, machines])
    col.find({trigTime: {$gte: from, $lte: to}, lastTrigTime: {$gte: from}, machineStatusType: {$ne: '系統啟動'}}).toArray(function (err, docs) {
      if (err) {
        reject(err)
      } else {
        console.log('from')
        console.log(docs)
        docs.forEach(doc => {
          if (doc['orderNumber'] !== undefined) {
            records.push(doc)
          }
        })
        resolve(records)
        console.log(from)
        console.log(to)
      }
    })
  })
}
app.get('/api/getNoteSelectedItem/', function (req, res) {
  MongoClient.connect(config.dbUrl, function(err, client) {
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else { 
      client.db(config.dbName).collection('sysConfig').findOne({_id: 'noteInfo'}, function(err0, docs0) {
        if (err0) {
          res.send({
            type: false,
            data: 'Error occured: ' + err0
          })
        } else {
          res.send({
            type: true,
            data: docs0
          })
        }
      })
    }
  })
})
app.get('/api/getMachineListRecords/:department/:zone/:reportDate', function (req, res) {
  var reportDate = moment(req.params.reportDate).format('YYYY-MM-DD HH:mm:ss')
  var subStr = firstDailyPoint.split(':')
  var from = moment(moment(reportDate).add(parseInt(subStr[0]), 'hours').add(parseInt(subStr[1]), 'minutes').format('YYYY-MM-DD HH:mm:ss')).toDate()
  var to = moment(moment(from).add(1,'day').format('YYYY-MM-DD HH:mm:ss')).toDate()
  var department = req.params.department
  var zone = req.params.zone
  // var reportDate = req.params.reportDate
  // var from = moment(moment(reportDate).format('YYYY-MM-DD')).toDate()
  // var to = moment(moment(reportDate).format('YYYY-MM-DD 23:59:59')).toDate()
  var idx = 0
  var retArray = []
  MongoClient.connect(config.dbUrl, function(err, client) {
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {     
      client.db(config.dbName).collection(config.machineListColName).find({'department': department}).sort({'machineID': 1}).toArray(function(err0, docs0) {
        if (err0) {
          res.send({
            type: false,
            data: 'Error occured: ' + err0
          })
        } else {          
          var idx= 0
          console.log(docs0)
          docs0.forEach(doc0 => {
            var col = client.db(config.dbName).collection(doc0.machineID)
            col.find({trigTime: {$gte: from, $lt: to}}).toArray(function (err1, docs1) {
              if (err1) {
                res.send({
                  type: false,
                  data: 'Error occured: ' + err1
                })
              } else {
                idx++
                docs1.forEach(doc1 => {
                  if (doc1['orderNumber'] === undefined) {
                    doc1['orderNumber'] = ''
                  }
                  retArray.splice(retArray.length, 0, doc1)
                })
                if(idx === docs0.length) {
                  res.send({
                    type: true,
                    data: retArray
                  })
                }
              }
            })
          })
        }
      })
    }
  })
})
app.get('/api/getDepartmentList/:department', function (req, res) {
  var department = req.params.department
  // console.log(machineID)
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  MongoClient.connect(config.dbUrl, function(err0, client){
    if (err0) {
      res.send({
        type: false,
        data: 'Error occured: ' + err0
      })
    } else {
      var col = client.db(config.dbName).collection(config.machineListColName)
      col.find().toArray(function (err, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          var departmentObj = {}
          var zoneObj = {}
          docs.forEach(element => {
            if(!departmentObj.hasOwnProperty(element['department'])) {
              departmentObj[element['department']] = Object.keys(departmentObj).length
            }
            if(element['department'] === department) {
              var machineIDsplit = (element['machineID']).substr(0, 2)
              if(!zoneObj.hasOwnProperty(machineIDsplit)) {
                zoneObj[machineIDsplit] = Object.keys(zoneObj).length
              }
            }
          })
          res.send({
            type: true,
            data: {
              department: departmentObj,
              zone: zoneObj
            }
          })
          console.log({
            department: departmentObj,
            zone: zoneObj
          })
        }
      })
    }
  })
})
app.get('/api/getDailyIntegratedReport/:department/:zone/:reportDate', function (req, res) {
  var department = req.params.department
  var zone = req.params.zone
  // var reportDate = req.params.reportDate
  // var from = moment(moment(reportDate).format('YYYY-MM-DD')).toDate()
  // var to = moment(moment(reportDate).format('YYYY-MM-DD 23:59:59')).toDate()
  var reportDate = moment(req.params.reportDate).format('YYYY-MM-DD HH:mm:ss')
  var subStr = firstDailyPoint.split(':')
  var from = moment(moment(reportDate).add(parseInt(subStr[0]), 'hours').add(parseInt(subStr[1]), 'minutes').format('YYYY-MM-DD HH:mm:ss')).toDate()
  var to = moment(moment(from).add(1,'day').format('YYYY-MM-DD HH:mm:ss')).toDate()
  var arrayRes = Array(6)
  var retArray = []
  var test = {}
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      client.db(config.dbName).collection(config.machineListColName).find({'department': department}).sort({'machineID': 1}).toArray(function(err0, docs0) {
        if (err0) {
          res.send({
            type: false,
            data: 'Error occured: ' + err0
          })
        } else {          
          var idx= 0
          docs0.forEach(doc0 => {
            client.db(config.dbName).collection(doc0.machineID).find({trigTime: {$gte: from, $lt: to},
              $where: 'this.orderNumber.length > 3',
              orderNumber: {$type : "string"}
            }).sort({'orderNumber': 1, 'trigTime': 1}).toArray(function(err1, docs1) {
              if (err1) {
                console.log('Error occured: ' + err0)
              } else {
                if(!test.hasOwnProperty(doc0.machineID)) {
                  test[doc0.machineID] = idx++
                }
                // var idx = 0
                var propIdx = 0
                var propObj = {}
                if(docs1.length > 0) {
                  docs1.forEach(doc1 => {
                    if(!propObj.hasOwnProperty(doc1.orderNumber)) {
                      propObj[doc1.orderNumber] = propIdx++
                    }
                  })
                  //var size = Object.keys(propObj).length
                  Object.keys(propObj).map(function(objectKey, indexMap) {
                    var value = propObj[objectKey]
                    var orderNumberDocs = docs1.filter(function(val) {
                      if(val.orderNumber === objectKey) {
                        return val
                      }
                    })
                        retArray.splice(retArray.length, 0, {
                          machineID: doc0.machineID,
                          first: false,
                          second: false,
                          third: false,
                          totalAlm: 0,
                          orderNumber: (orderNumberDocs.filter(function(val, index) {
                            if(index === 0) {
                              return val.orderNumber
                            }
                          }))[0].orderNumber,
                          product: (orderNumberDocs.filter(function(val, index) {
                            if(index === 0) {
                              return val.product
                            }
                          }))[0].product,
                          cavities: (orderNumberDocs.filter(function(val, index) {
                            if(index === 0) {
                              return val
                            }
                          }))[0].cavities || 0,
                          trigTime: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return val.trigTime
                            }
                          }))[0].trigTime,
                          lastTrigTime: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === (arr.length - 1)) {
                              return val.lastTrigTime
                            }
                          }))[0].lastTrigTime,
                          duration: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === (arr.length - 1)) {
                              return val.resultCal = arr[index].lastTrigTime - arr[0].trigTime
                            }
                          }))[0].resultCal,
                          moldCount: (orderNumberDocs.reduce(function (previousValue, currentValue, index, array) {
                            return previousValue + currentValue.moldCount  
                          }, 0)),
                          predProductCnt: (orderNumberDocs.reduce(function (previousValue, currentValue, index, array) {
                            return previousValue + currentValue.moldCount * currentValue.cavities 
                          }, 0)),
                          standard: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return arr[index]
                            }
                          }))[0].standard,
                          min: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return arr[index]
                            }
                          }))[0].min,
                          average: ((orderNumberDocs.filter(function(val, index, arr) {
                            if(index === (arr.length - 1)) {
                              return val.resultCal = arr[index].lastTrigTime - arr[0].trigTime
                            }
                          }))[0].resultCal / (orderNumberDocs.reduce(function (previousValue, currentValue, index, array) {
                            return previousValue + currentValue.moldCount  
                          }, 0))),
                          performance: 0,
                          predMoldCnt: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                            return arr[index]
                          }
                          }))[0].predMoldCnt,
                          accMoldCnt: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return arr[index]
                            }
                          }))[0].accMoldCnt,
                          percentage: ((orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return arr[index]
                            }
                          }))[0].accMoldCnt / (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === 0) {
                              return arr[index]
                            }
                          }))[0].predMoldCnt), 
                          tgtfinishTime: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === (arr.length - 1)) {
                              return val
                            }
                          }))[0].lastTrigTime,
                          deadline: (orderNumberDocs.filter(function(val, index, arr) {
                            if(index === (arr.length - 1)) {
                              return val
                            }
                          }))[0].deadline
                        })
                  })
                }
                if(idx === docs0.length) {
                  res.send({
                    type: true,
                    data: retArray
                  })
                }
              }
            })
          })
        }
      })
    }
  })
})
//----------------------------------------------------------------------------
app.get('/api/updateMonitorHWCfg/:department', function (req, res) {
  var department = req.params.department
  var arrayRes = Array(6)
  var replacerArray = []
  console.log('1')
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      console.log('2')
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      console.log('3')
      var db = client.db(config.dbName)
      var  i = 0
      db.collection(config.machineListColName).find({'department': department}).count()
        .then(function(idx0) {
          arrayRes[0] = idx0
        })
      db.collection(config.machineListColName).find({'department': department}, {}, function (err0, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {          
          var idx= 0
          docs.forEach(doc0 => {
            replacerArray.splice(replacerArray.length, 0, {
              'machineID': doc0.machineID
            })
            idx++
            if (arrayRes[0] === idx) {
              var jsonText = JSON.stringify(replacerArray)
              db.collection('lastDeviceID').find({'machineID': {$gte: '1A01', $lte: '1A09'}}).toArray( function (err1, docs1) {
                if (err1) {
                  res.send({
                    type: false,
                    data: 'Error occured: ' + err1
                  })
                } else {
                  docs1.forEach(doc1 =>{
                    db.collection(doc1.machineID).findOne({'_id': doc1.last}, function(err2, doc2) {
                      for(recv in monitorModalClientList) {
                        monitorModalClientList[recv].emit('showMachineSts', doc2)
                      }
                    })
                  })
                  var autoArray = docs1.filter((val) => {
                    return val['STS'] === '全自動'
                  })
                  arrayRes[2] = autoArray.length
                  autoArray = docs1.filter((val) => {
                    return val['STS'] === '半自動'
                  })
                  arrayRes[3] = autoArray.length
                  autoArray = docs1.filter((val) => {
                    return val['STS'] === '手動'
                  })
                  arrayRes[4] = autoArray.length
                  autoArray = docs1.filter((val) => {
                    return val['STS'] === '關機'
                  })
                  arrayRes[5] = autoArray.length
                  arrayRes[1] = arrayRes[2] + arrayRes[3]
                  res.send({
                    type: true,
                    data: arrayRes
                  })
                }
              })
            }
          }) 
        }
      })
    }
  })
})
app.get('/api/updateModalHWCfg/:machineID', function (req, res) {
  var machineID = req.params.machineID
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      var db = client.db(config.dbName)
      db.collection(config.machineListColName).find({'machineID': machineID}, {}, function (err0, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          docs.forEach(doc0 => {
            //console.log(doc0)
            res.send({
              type: true,
              data: doc0
            })
          })
        }
      })
    }
  })
})
app.get('/api/getMachineCurrInfo/:machineID', function (req, res) {
  var machineID = req.params.machineID
  var _id = undefined
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      var db = client.db(config.dbName)
      var col = db.collection('lastDeviceID')
      col.find({'machineID': machineID}, {}, function (err, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          console.log(machineID)
          var col1 = db.collection(machineID)
          docs.forEach(doc => {
            console.log(doc.last)
            _id = doc.last
            col1.find({'_id': _id}, {}, function (err0, docs0) {
              if (err0) {
                console.log('ERRRR')
                res.send({
                  type: false,
                  data: 'Error occured: ' + err0
                })
              } else {
                docs0.forEach(doc0 => {
                  console.log(doc0)
                  res.send({
                    type: true,
                    data: doc0
                  })
                })
              }
            })
          })   
        }
      })
    }
  })
})
app.get('/api/getMachineSts/:from/:to', function (req, res) {
  var from = req.params.from
  var to = req.params.to
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      var db = client.db(config.dbName)
      var col = db.collection(config.machineListColName)
      console.log('property')
      console.log(hwCfgList)
      console.log('1111111')
      var selected = hwCfgList.filter(function (elm) {
        console.log(elm['machineID'])
        if ((from <= elm['machineID']) && (to >= elm['machineID']))
        {
          return elm
        }
      })
      console.log('property')
      console.log(selected)
      selected.forEach(elm => {
        console.log(elm['machineID'])
        console.log(elm['propertyNum'])
      })
      col.find({'machineID': {$gte: from, $lte: to}}, {}, function (err, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          docs.forEach(doc => {
            console.log(doc.machineID)
          })  
          /* res.send({
            type: true,
            data: null
          }) */
        }
      })
    }
    db.collection('lastDeviceID').find({}).toArray( function (err0, docs0){
      if (err0) {
        res.send({
          type: false,
          data: 'Error occured: ' + err0
        })
      } else {
        docs0.forEach(doc0 => {
          console.log(doc0.machineID)
          console.log(doc0.STS)
        })
        res.send({
          type: true,
          data: docs0
        })
      }
    })
  })
})
app.get('/api/updateShiftTable/:machineID/:tgtDate/:shift/:newData', function (req, res) {
  var machineID = req.params.machineID
  var tgtDate = req.params.tgtDate
  var shift = req.params.shift
  var newData = (req.params.newData === 'true')
  console.log(machineID)
  console.log(tgtDate)
  console.log(shift)
  console.log(newData)
  MongoClient.connect(config.dbUrl, function(err, client){
    if (err) {
      res.send({
        type: false,
        data: 'Error occured: ' + err
      })
    } else {
      var year = moment(tgtDate, 'YYYY-MM-DD').add(0, 'd').format('Y')
      var id = moment(tgtDate, 'YYYY-MM-DD').add(0, 'd').format('YYYY/M/D')
      var db = client.db('calendar' + year)
      var col = db.collection(machineID)
      //col.update({'_id': {$eq: id}}, {$set: {[shift]:newData}})
      col.findOneAndUpdate({'_id': {$eq: id}}, {$set: {[shift]:newData}}, {returnOriginal: false}, function (err0, doc) {
        if (err0) {
          res.send({
            type: false,
            data: 'Error occured: ' + err0
          })
        } else {
          console.log(doc)
          console.log(doc.value[shift])
          res.send({
            type: true,
            data: doc.value[shift]
          })
        }
      })
    } 
  })  
})

app.get('/api/getCalendar/:machineID/:year/:month/:day', function (req, res) {
  var year =  req.params.year
  var month = req.params.month
  var day = req.params.day
  var machineID = req.params.machineID // '1A09'
  console.log(year+ '/' + month + '/' + day)
  var V = config.dbUrl + 'calendar' + year
  // MongoClient.connect(config.dbUrl + config.calendar).then(db => {
  MongoClient.connect(config.dbUrl, function(err, client){ 
    var db = client.db('calendar' + year)
    var col = db.collection(machineID)
    var index = 0
    var docsN = []
    col.find({'date': {$gte: new Date(year + '/' + month + '/' + day)}}).toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        if (docs.length > 0) { 
          docs.forEach(doc => {
            if (index < 7) {
              docsN.push(doc)
              index++
            }
          })
          
          res.send({
            type: true,
            data: docsN
          })
        }
      }      
    })
  })
})
//---------------------------------------------------------------------------
app.get('/api/getMachineRecords/:machineID/:reportDate', function (req, res) {
  var machineID = req.params.machineID
  var reportDate = moment(req.params.reportDate).format('YYYY-MM-DD HH:mm:ss')
  var subStr = firstDailyPoint.split(':')
  var from = moment(moment(reportDate).add(parseInt(subStr[0]), 'hours').add(parseInt(subStr[1]), 'minutes').format('YYYY-MM-DD HH:mm:ss')).toDate()
  // var to = moment(moment(reportDate).format('YYYY-MM-DD 23:59:59')).toDate()
  var to = moment(moment(from).add(1,'day').format('YYYY-MM-DD HH:mm:ss')).toDate()
  console.log(moment(moment(moment(req.params.reportDate).format('YYYY-MM-DD')).toDate()).add(8,'hours').format('YYYY/M/D HH:mm:ss'))
  console.log(subStr[0])
  console.log(parseInt(subStr[0]))
  console.log(from)
  console.log(to)
  // console.log([from, to])
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  // , function (err, client) {
  MongoClient.connect(config.dbUrl, function (err0, client) {
    if (err0) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    } else {
      var col = client.db(config.dbName).collection(machineID)
      // col.find({Trig_Time: {$gte: date}}).toArray(function (err, docs) {
      // col.find().toArray(function (err, docs) {
      col.find({trigTime: {$gte: from, $lt: to}}).toArray(function (err, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          docs.forEach(doc => {
            if (doc['orderNumber'] === undefined) {
              doc['orderNumber'] = ''
            }
          })
          // console.log(JSON.stringify(docs, null, 2))
          res.send({
            type: true,
            data: docs
          })
        }
        // db.close()
      })
    }
  }) /* .catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  }) */
})
app.get('/api/getCalendar/:machineID/:year', function (req, res) {
  var year = req.params.year
  var machineID = req.params.machineID
  MongoClient.connect(config.dbUrl, function (err0, client) {
    if (err0) {
      res.send({
        type: false,
        data: 'Error occured: ' + err0
      })
    } else {
      client.db(config.calendarDbNamePrefix + year).collection(machineID).find().toArray(function (err, docs) {
        if (err) {
          res.send({
            type: false,
            data: 'Error occured: ' + err
          })
        } else {
          // console.log(JSON.stringify(docs, null, 2))
          res.send({
            type: true,
            data: docs
          })
        }
      })
    }
  })
})
app.get('/api/calendar/:machineID/:year', function (req, res) {
  var year = req.params.year
  var machineID = req.params.machineID
  MongoClient.connect(config.dbUrl + config.calendarDbNamePrefix + year).then(db => {
    var col = db.collection(machineID)
    // col.find({Trig_Time: {$gte: date}}).toArray(function (err, docs) {
    // col.find().toArray(function (err, docs) {
    col.find().toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        // console.log(JSON.stringify(docs, null, 2))
        res.send({
          type: true,
          data: docs
        })
      }
      db.close()
    })
  }).catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.calendarDbNamePrefix + year}`
      })
    }
  })
})

/*
app.post('/api/setRecordOrderNumber/:machineID', function (req, res) {
  // console.log(JSON.stringify(req.params.machineID, null, 2))
  // console.log(JSON.stringify(req.body, null, 2))
  {
    "action": "edit",
      "data": {
        "59c8e771d485cdca196cc0da": {
          "orderNumber": "2"
        }
      }
  }

  var id = Object.keys(req.body.data)[0]
  var machineID = req.params.machineID
  var orderNumber = req.body.data[id]['orderNumber']

  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(machineID)

    // find the original record, because we need to get complete information for response
    col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        var oldProduct
        var newProduct

        if (docs.length === 0) {
          console.log('no data')
          res.send({
            type: false,
            'data': [
            ]
          })
        } else {
          var doc = docs[0]

          // use to compare the new value has updated
          oldProduct = doc['product']

          // notify the server that the order number is changed, and wait for product update
          col = db.collection(config.calHandleCommandColName)
          col.insertOne({
            id: id,
            machineID: machineID,
            orderNumber: orderNumber,
            opcode: opcodes.set_order_opcode
          }).then(result => {
            // console.log(result)
            col = db.collection(machineID)
            var timeout = 0

            // query the change per second
            var waitFunc = setInterval(function () {
              timeout++
              // doc['orderNumber'] = orderNumber

              // maximum wait 30 secs, if timeout, just reply the origin record
              if (timeout >= 30) {
                clearInterval(waitFunc)
                res.send({
                  'data': [
                    doc
                  ]
                })
                db.close()
              } else {
                // query the record and judge the product has changed or not yet
                col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
                  if (err) {
                    res.send({
                      type: false,
                      data: 'Error occured: ' + err
                    })
                  } else {
                    if (docs.length === 0) {
                      console.log('no data')
                      res.send({
                        type: false,
                        'data': [
                        ]
                      })
                    } else {
                      doc = docs[0]
                      newProduct = doc['product']
                      if (oldProduct !== undefined && newProduct !== undefined && oldProduct !== newProduct) {
                        clearInterval(waitFunc)
                        res.send({
                          'data': [
                            doc
                          ]
                        })
                        db.close()
                      }
                    }
                  }
                })
              }
            }, 1000)
          })
        }
      }
    })
  }).catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  })
})
*/

app.get('/api/getOrderList', function (req, res) {
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  MongoClient.connect(config.dbUrl, function (err0, client) {
    var col = client.db(config.dbName).collection(config.orderListColName)
    col.find().toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        // console.log(JSON.stringify(docs, null, 2))
        res.send({
          type: true,
          data: docs
        })
      }
      // db.close()
    })
  }) /* .catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  }) */
})

app.get('/api/getMachineList', function (req, res) {
  // console.log(machineID)
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  MongoClient.connect(config.dbUrl, function (err0, client) {
    var col = client.db(config.dbName).collection(config.machineListColName)
    col.find().toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        res.send({
          type: true,
          data: docs
        })
      }
      // db.close()
    })
  }) /* .catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  }) */
})

app.get('/api/getDepartmentList', function (req, res) {
  // console.log(machineID)
  var departmentList = []
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  MongoClient.connect(config.dbUrl, function (err0, client) {
    var col = client.db(config.dbName).collection(config.machineListColName)
    col.find().toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        docs.forEach(doc => {
          if (departmentList.indexOf(doc.department) === -1) {
            departmentList.push(doc.department)
          }
        })
        res.send({
          type: true,
          data: departmentList
        })
      }
      // db.close()
    })
  }) /* .catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  }) */
})

app.post('/api/fileUpload', function (req, res) {
  // console.log(JSON.stringify(req.body, null, 2))
  var form = new formidable.IncomingForm()
  form.parse(req, function (err, fields, files) {
    if (err) {
      throw err
    }
    // console.log(files)
    var oldpath = files.file.path
    var newpath = path.resolve(path.join(config.uploadFolder) + files.file.name)
    // console.log(newpath)
    var readStream = fs.createReadStream(oldpath)
    var writeStream = fs.createWriteStream(newpath)

    readStream.pipe(writeStream)
    readStream.on('end', function () {
      // Operation done
      fs.unlinkSync(oldpath)
      res.send({
        type: true,
        data: [{
        }]
      })
      // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
      MongoClient.connect(config.dbUrl, function (err0, client) {
        var col = client.db(config.dbName).collection(config.calHandleCommandColName)
        col.insertOne({
          fileName: files.file.name,
          opcode: opcodes.notify_upload_opcode
        })/* .then(result => {
          db.close()
        }) */
      })
    })
  })
})

app.get('/api/getFileMappingTable', function (req, res) {
  // console.log(machineID)
  MongoClient.connect(config.dbUrl + config.fileMappingDbName).then(db => {
    var col = db.collection(config.fileNameColName)
    col.find().toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        res.send({
          type: true,
          data: docs
        })
      }
      db.close()
    })
  }).catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  })
})

app.post('/api/setFileName', function (req, res) {
  // console.log(JSON.stringify(req.body, null, 2))
  res.send({
    type: true
  })
  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(config.calHandleCommandColName)
    col.insertOne({
      opcode: opcodes.set_file_name_opcode,
      tgtDocId: req.body.type,
      fileName: req.body.name
    }).then(result => {
      db.close()
    })
  })
})

app.post('/api/setSheetName', function (req, res) {
  // console.log(JSON.stringify(req.body, null, 2))
  res.send({
    type: true
  })
  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(config.calHandleCommandColName)
    col.insertOne({
      opcode: opcodes.set_sheet_name_opcode,
      tgtDocId: req.body.type,
      sheetName: req.body.name
    }).then(result => {
      db.close()
    })
  })
})

app.post('/api/setIndexName', function (req, res) {
  // console.log(JSON.stringify(req.body, null, 2))
  res.send({
    type: true
  })
  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(config.calHandleCommandColName)
    col.insertOne({
      opcode: opcodes.set_index_name_opcode,
      tgtDocId: req.body.type,
      keyName: req.body.name
    }).then(result => {
      db.close()
    })
  })
})

app.post('/api/uploadAllFiles', function (req, res) {
  // console.log(JSON.stringify(req.body, null, 2))
  res.send({
    type: true
  })
  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(config.calHandleCommandColName)
    col.insertOne({
      opcode: opcodes.upload_all_files
    }).then(result => {
      db.close()
    })
  })
})
/*
app.get('/api/staff', function (req, res) {
  // console.log(machineID)
  res.send({
    "data": [
      {
        "DT_RowId": "row_1",
        "first_name": "Tiger",
        "last_name": "Nixon",
        "position": "System Architect",
        "email": "t.nixon@datatables.net",
        "office": "Edinburgh",
        "extn": "5421",
        "age": "61",
        "salary": "320800",
        "start_date": "2011-04-25"
      },
      {
        "DT_RowId": "row_2",
        "first_name": "Garrett",
        "last_name": "Winters",
        "position": "Accountant",
        "email": "g.winters@datatables.net",
        "office": "Tokyo",
        "extn": "8422",
        "age": "63",
        "salary": "170750",
        "start_date": "2011-07-25"
      }
    ],
    "options": [],
    "files": []
  })
})

app.post('/api/staff', function (req, res) {
  // console.log(machineID)
  res.send({
    "data": [
      {
        "DT_RowId": "row_5",
        "first_name": "Airi",
        "last_name": "Satou",
        "position": "asdadsad",
        "email": "a.satou@datatables.net",
        "office": "Tokyo",
        "extn": "5407",
        "age": "33",
        "salary": "162700",
        "start_date": "2008-11-28"
      }
    ]
  })
})
*/

function getEachMachineRecords (db, machineID, from, to) {
  return new Promise((resolve, reject) => {
    var records = []
    var col = db.collection(machineID)

    // console.log(machineID)
    // console.log([db, machineID, from, to, machines])
    col.find({trigTime: {$gte: from, $lte: to}, lastTrigTime: {$gte: from}, machineStatusType: {$ne: '系統啟動'}}).toArray(function (err, docs) {
      if (err) {
        reject(err)
      } else {
        docs.forEach(doc => {
          if (doc['orderNumber'] !== undefined) {
            records.push(doc)
          }
        })
        resolve(records)
      }
    })
  })
}

app.get('/api/getPeriodMachineRecords/:departmentID/:from/:to', function (req, res) {
  var departmentID = req.params.departmentID
  var from = new Date(req.params.from)
  var to = new Date(req.params.to)
  console.log([from, to])

  var machines = {}
  // MongoClient.connect(config.dbUrl + config.dbName).then(db => {
  MongoClient.connect(config.dbUrl, function (err0, client) {
    db = client.db(config.dbName)
    var col = db.collection(config.machineListColName)
    col.find({department: departmentID}).toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        var promises = []
        docs.forEach(doc => {
          var machineID = doc.machineID
          promises.push(getEachMachineRecords(db, machineID, from, to).then(results => {
            machines[machineID] = results
          }))
        })

        Promise.all(promises).then(() => {
          res.send({
            type: true,
            data: machines
          })
          // db.close()
        }).catch(err => {
          console.log(err)
          res.send({
            type: false
          })
          // db.close()
        })
      }
    })
  }) /* .catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  }) */
})

/*
app.post('/api/setProductWarehousing/:departmentID', function (req, res) {
  // console.log(JSON.stringify(req.params.machineID, null, 2))
  console.log(JSON.stringify(req.body, null, 2))
  var departmentID = req.params.departmentID
  var id = Object.keys(req.body.data)[0]
  console.log(departmentID)

  res.send({
    type: false,
    'data': [
    ]
  })

  MongoClient.connect(config.dbUrl + config.dbName).then(db => {
    var col = db.collection(config.machineListColName)
    col.find({department: departmentID}).toArray(function (err, docs) {
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        var promises = []
        docs.forEach(doc => {
          var machineID = doc.machineID
          promises.push(getEachMachineRecords(db, machineID, from, to).then(results => {
            machines[machineID] = results
          }))
        })

        Promise.all(promises).then(() => {
          res.send({
            type: true,
            data: machines
          })
          db.close()
        }).catch(err => {
          console.log(err)
          res.send({
            type: false
          })
          db.close()
        })
      }
    })
  }).catch(err => {
    if (err) {
      res.send({
        type: false,
        data: `Can't connect to ${config.dbUrl}${config.dbName}`
      })
    }
  })
})
*/
app.get('/api/firstDailyPoint', function (req, res) {
  console.log(firstDailyPoint)
  res.send({
    type: true,
    data: firstDailyPoint
  })
})
var firstDailyPoint = ''
var hwCfgList = []
function getFirstDailyPoint () {
  console.log(config.dbUrl)
  MongoClient.connect(config.dbUrl, function (err, client) {
    if (err) {
      console.log('Data is gone')
      var initDoc = {
        '_id': 'timeSlicePoint',
        '日切換點': '08:00',
        '時段點1': '12:00',
        '時段點2': '16:30',
        '時段點3': '20:00',
        '時段點4': '23:00'
      }
      // client.db(config.dbName).collection(config.sysConfig).insertOne(initDoc)
      firstDailyPoint = '08:00'
      console.log('new')
      console.log(firstDailyPoint)
    } else {
      var doc = client.db(config.dbName).collection(config.sysConfig).findOne({'_id': config.timeSlicePoint})
      Promise.all([doc]).then((val) => {
        firstDailyPoint = (val[0])['日切換點']
        console.log(val)
        console.log(firstDailyPoint)
      }).catch(err => {
        console.log('Data is gone')
        var initDoc = {
          '_id': 'timeSlicePoint',
          '日切換點': '08:00',
          '時段點1': '12:00',
          '時段點2': '16:30',
          '時段點3': '20:00',
          '時段點4': '23:00'
        }
        client.db(config.dbName).collection(config.sysConfig).insertOne(initDoc)
        firstDailyPoint = '08:00'
        console.log('new')
        console.log(firstDailyPoint)
      })
    }
  })
}
function getHwCfg () {
  MongoClient.connect(config.dbUrl, function (err, client) {
    if (err) {
    } else {
      client.db(config.dbName).collection(config.machineListColName).find({}).toArray(function (err1, docs) {
        if(err1) {

        } else {
          hwCfgList = docs
        }
      })
    }
  })
}
var clientList = {}
var clientListIndex = 0
var monitorModalClientList = {}
var monitorModalClientIndex = 0
var dailyReportIntegratedClientList = {}
var dailyReportIntegratedClientIndex = 0
server.listen(app.get('port'), function () {
  console.log('Express server listening on port ' + app.get('port'))
  getFirstDailyPoint()
  getHwCfg()
})

var socket = io.listen(server)
socket.on('connection', function (client) {
  console.log('A connection was established')
  client.on('disconnect', function () {
    console.log('Server has disconnected')
  })
  //----------------------------------
  client.on('setNoteInfo', function (data) {
    console.log(data)
    var id = data._id
    var machineID = data.machineID
    var note = data.note
    MongoClient.connect(config.dbUrl, function (err, client) {
      if (err) {
        socket.emit('setNoteInfoRes', '')
      } else {
        var doc = client.db(config.dbName).collection(machineID).findOneAndUpdate({_id: ObjectID(id)}, {$set: {'note': note}}, {returnOriginal : false})
        Promise.all([doc]).then((val) => {
          // all loaded
          console.log(val)
          console.log('doc')
          socket.emit('setNoteInfoRes', val[0].value)
          console.log(val[0].value)
        }).catch(err => {
          socket.emit('setNoteInfoRes', '')
        })
      }
    })
  })
  client.on('commCommand', function (data) {
    var objectId = new ObjectID();
    socket.emit(data, objectId)
    console.log(objectId)
  })
  client.on('addClientMonitor', function (data) {
    if(!monitorModalClientList.hasOwnProperty(data))
    {
      monitorModalClientList[data] = socket
      monitorModalClientIndex++
      console.log(monitorModalClientList)
    }
  })
  client.on('deleteClientMonitor', function (data) {
    if(monitorModalClientList.hasOwnProperty(data))
    {
      delete monitorModalClientList[data]
      monitorModalClientIndex--
      console.log(monitorModalClientList)
    }
  })
  //---------------------------------------
  client.on('addClientDailyReportIntegrated', function (data) {
    if(!dailyReportIntegratedClientList.hasOwnProperty(data))
    {
      dailyReportIntegratedClientList[data] = socket
      dailyReportIntegratedClientIndex++
      console.log(dailyReportIntegratedClientList)
    }
  })
  client.on('deleteClientDailyReportIntegrated', function (data) {
    if(dailyReportIntegratedClientList.hasOwnProperty(data))
    {
      delete dailyReportIntegratedClientList[data]
      dailyReportIntegratedClientIndex--
      console.log(dailyReportIntegratedClientList)
    }
  })
  client.on('reqUpdateShiftDailyReportIntegrated', function (data) {
    var machineID = data.machineID
    var orderNumber = data.orderNumber
    var reportDate = moment(data.reportDate).format('YYYY-MM-DD')
    var trigTime = moment(data.trigTime).format('HH:mm:ss').toString()
    var lastTrigDate = moment(data.lastTrigTime).format('YYYY-MM-DD')
    var lastTrigTime = ''
    if(reportDate < lastTrigDate) {
      lastTrigTime = moment(moment(moment(data.lastTrigTime).format('HH:mm:ss')).hour() + 24).toString() + ':' + 
      moment(moment(moment(data.lastTrigTime).format('HH:mm:ss')).minute()).toString() + ':' +
      moment(moment(moment(data.lastTrigTime).format('HH:mm:ss')).second()).toString()
    } else {
      lastTrigTime = moment(data.lastTrigTime).format('HH:mm:ss').toString()
    }
    
    console.log('calendar' + moment(reportDate).year())
    console.log(trigTime)
    console.log(lastTrigTime)
    console.log(data.lastTrigTime)
    var startDate =  moment(reportDate).format('YYYY/M/D')
    var first = false
    var second = false
    var third = false
    MongoClient.connect(config.dbUrl, function(err, client){
      if (err) {
        res.send({
          type: false,
          data: 'Error occured: ' + err
        })
      } else {
        client.db('calendar' + moment(reportDate).year()).collection(machineID).findOne({_id: {$eq: startDate}}, function(err2, doc2){
          if(err2) {
            first = false
            second = false
            third = false
            console.log('err2')
          } else {
            console.log(doc2)
            console.log(trigTime)
            console.log(lastTrigTime)
            // ------------------------------------------------------------------------------
            if((trigTime >= doc2['firstS']) && (trigTime < doc2['firstE'])) {
              first = doc2['first']
            } else if((lastTrigTime >= doc2['firstS']) && (lastTrigTime < doc2['firstE'])) {
              first = doc2['first']
            } else if((trigTime <= doc2['firstS']) && (lastTrigTime >= doc2['firstE'])) {
              first = doc2['first']
            }
            // ------------------------------------------------------------------------------
            if((trigTime >= doc2['secondS']) && (trigTime < doc2['secondE'])) {
              second = doc2['second']
            } else if((lastTrigTime >= doc2['secondS']) && (lastTrigTime < doc2['secondE'])) {
              second = doc2['second']
            } else if((trigTime <= doc2['secondS']) && (lastTrigTime >= doc2['secondE'])) {
              second = doc2['second']
            }
            // ------------------------------------------------------------------------------
            if((trigTime >= doc2['thirdS']) && (trigTime < doc2['thirdE'])) {
              third = doc2['third']
            } else if((lastTrigTime >= doc2['thirdS']) && (lastTrigTime < doc2['thirdE'])) {
              third = doc2['third']
            } else if((trigTime <= doc2['thirdS']) && (lastTrigTime >= doc2['thirdE'])) {
              third = doc2['third']
            }
            var retObj = {
              machineID: machineID,
              orderNumber: orderNumber,
              first: first,
              second: second,
              third: third
            }
            socket.emit('updateShiftDailyReportInteg', retObj)
          }
        })
      }
    })
  })
  //---------------------------------------
  client.on('setOrderNumber', function (data) {
    console.log(data)

    var id = data._id
    var machineID = data.machineID
    var orderNumber = data.orderNumber
    var trigTime = data.trigTime

    MongoClient.connect(config.dbUrl, function(err, client) {
      if (err) {
        socket.emit('setOrderNumberFail', data)
      } else {
        var col = client.db('pmDB').collection('成型派單明細')
        col.findOne({'派單號碼': {$eq: orderNumber}}, function(err, orderDetail) {
          if (err) {
            socket.emit('setOrderNumberFail', data)
          } else {
            client.db('pmDB').collection('貨品資料對應可生產模具').findOne({'_id':orderDetail['成品料號']}, function(err1, moldDetail) {
              if (err1) {
                socket.emit('setOrderNumberFail', data)
              } else {
                console.log('setOrderNumber')
                console.log(orderDetail)
                console.log(moldDetail)
                var moldDetailKey = Object.keys(moldDetail)
                var availableMoldKey = moldDetailKey.filter(elm => elm.includes('可用模具'))
                var arr = []
                availableMoldKey.forEach(function(elm) {
                  arr.splice(arr.length, 0, moldDetail[elm])
                })
                console.log(arr)
                console.log(trigTime)
                client.db(config.dbName).collection(machineID).findOne({'_id': ObjectID(id)}, function(err2, doc) {
                  if (err2) {
                    socket.emit('setOrderNumberFail', data)
                  } else {
                    console.log(doc)
                    client.db(config.dbName).collection(machineID).updateMany({
                      $and: [ {'trigTime': {$lte: doc.trigTime}},
                      { $or: [
                        // {'orderNumber': {$exists: false}},
                        // {'orderNumber': {$eq: ''}},
                        // {'orderNumber': {$type: 'null'}},
                        {'orderNumber': {$eq: orderNumber}},
                        {'_id': {$eq: ObjectID(id)}}
                      ]},
                      { $or: [
                        {'machineStatusType': {$eq: '全自動'}},
                        {'machineStatusType': {$eq: '半自動'}},
                        {'machineStatusType': {$eq: '警報'}}
                      ]},
                      { $or: [
                        // {'moldNum': {$exists:false}},
                        // {'moldNum': {$eq:''}},
                        {'moldNum': {$type: 'null'}},
                        {'_id': {$eq: ObjectID(id)}}
                      ]}]
                    },{
                      $set: {
                        'product': orderDetail['成品料號'],
                        'standard': 0,
                        'orderNumber': orderNumber,
                        'performance': orderDetail['成品料號'],
                        'deadline': orderDetail['最遲完成日'],
                        'targetCount': orderDetail['派單數量'],
                        'badNum': 0,
                        'badRate': 0,
                        'totalAlm': 0,
                        'warehousing': 0,
                        'componentNum': moldDetail['零件模號'],
                        'moldNum': arr[0],
                        'moldArray': arr,
                        'prodName': orderDetail['成品名稱'],
                        'predMachine': orderDetail['生產機台'],
                        'predMoldCnt': orderDetail['生產模數'],
                        'cavities': 0,
                        'standard': 0,
                        'moldName':''
                      }
                    }, function(err3) {
                      console.log('Update Finish')
                      client.db(config.dbName).collection(machineID).findOne({'_id': ObjectID(id)}, function(err4, doc) {
                        if (err4) {
                          socket.emit('setOrderNumberFail', data)
                        } else {
                          console.log('setOrderNumberSuccess')
                          socket.emit('setOrderNumberSuccess', doc)
                        }
                      })
                      console.log('id')
                      console.log(config.dbName)
                      console.log(machineID)
                      console.log(orderNumber)
                      console.log(id)
                      // 
                      // var oldOrderNumber = [doc['orderNumber'], orderNumber]
                      // oldOrderNumber.forEach(function (elm) {
                    })
                  }
                })
              }
            })
          }
        })
      }
    })
      // find the original record, because we need to get complete information for response
  })
  /* client.on('setOrderNumber', function (data) {
    console.log(data)

    var id = data._id
    var machineID = data.machineID
    var orderNumber = data.orderNumber

    MongoClient.connect(config.dbUrl + config.dbName).then(db => {
      var col = db.collection(machineID)

      // find the original record, because we need to get complete information for response
      col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
        if (err) {
          socket.emit('setOrderNumberFail', data)
        } else {
          if (docs.length === 0) {
            console.log('no data')
            data.orderNumber = ''
            socket.emit('setOrderNumberFail', data)
          } else {
            var doc = docs[0]

            // notify the server that the order number is changed, and wait for product update
            col = db.collection(config.calHandleCommandColName)
            col.insertOne({
              id: id,
              machineID: machineID,
              orderNumber: orderNumber,
              opcode: opcodes.set_order_opcode
            }).then(result => {
              // console.log(result)
              col = db.collection(machineID)

              // var testFlag = true
              // if (testFlag) { // for test
              //   col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
              //     if (err) {
              //       data.orderNumber = ''
              //       socket.emit('setOrderNumberFail', data)
              //     } else {
              //       if (docs.length === 0) {
              //         console.log('no data')
              //         data.orderNumber = ''
              //         socket.emit('setOrderNumberFail', data)
              //       } else {
              //         doc = docs[0]
              //         doc['product'] = 'new product'
              //         doc['moldArray'] = ['x', 'y', 'z']
              //         doc['orderNumber'] = orderNumber
              //         socket.emit('setOrderNumberSuccess', doc)
              //         db.close()
              //       }
              //     }
              //   })
              // }

              // col.updateOne({'_id': ObjectID(id)}, { $set: {
              //   product: 'new product',
              //   orderNumber: orderNumber,
              //   moldArray: ['x', 'y', 'z']
              // } }).then(rlt => {
              //   console.log(rlt)
              // })

              var newOrderNumber
              var timeout = 0

              // query the change per second
              var waitFunc = setInterval(function () {
                timeout++

                // maximum wait 30 secs, if timeout, just reply the origin record
                if (timeout >= 5) {
                  clearInterval(waitFunc)
                  data.orderNumber = doc.orderNumber
                  socket.emit('setOrderNumberFail', data)
                  db.close()
                } else {
                  // query the record and judge the product has changed or not yet
                  col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
                    if (err) {
                      data.orderNumber = ''
                      socket.emit('setOrderNumberFail', data)
                    } else {
                      if (docs.length === 0) {
                        console.log('no data')
                        data.orderNumber = ''
                        socket.emit('setOrderNumberFail', data)
                      } else {
                        doc = docs[0]
                        newOrderNumber = doc['orderNumber']
                        if (newOrderNumber !== undefined && newOrderNumber === orderNumber) {
                          clearInterval(waitFunc)
                          socket.emit('setOrderNumberSuccess', doc)
                          db.close()
                        }
                      }
                    }
                  })
                }
              }, 1000)
            })
          }
        }
      })
    }).catch(err => {
      if (err) {
        data.orderNumber = ''
        socket.emit('setOrderNumberFail', data)
      }
    })
  }) */

  client.on('setMoldNumber', function (data) {
    console.log(data)
    var id = data._id
    var machineID = data.machineID
    var moldNum = data.moldNum
    var product = data.product
    MongoClient.connect(config.dbUrl, function(err, client) {
      if (err) {
        socket.emit('setOrderNumberFail', data)
      } else {
        console.log(config.prodDBName)
        console.log(config.moldListColName)
        console.log(moldNum)
        client.db(config.prodDBName).collection(config.moldListColName).findOne({'模具編號': moldNum}, function(err1, doc) {
          if (err1) {
            socket.emit('findMoldListFail', data)
          } else {
            console.log(doc)
            var promises = []
            client.db(config.dbName).collection(machineID).updateMany({$and: [{'product': {$eq: product}}, {'moldArray': {$elemMatch: {$eq: moldNum}}}]}, { 
              $set: { 
                "cavities" : doc['穴數'],
                "standard" : doc['成型週期'],
                "moldNum" : moldNum,
                "moldName" : doc[' 零  件  名  稱   ']
              } 
            }).then(() => {
              client.db(config.dbName).collection(machineID).findOne({'_id': ObjectID(id)}, function(err3, doc1) {
                if (err3) {
                  socket.emit('setOrderNumberFail', data)
                } else {
                  console.log('setMoldNumberSuccess')
                  console.log(doc1['cavities'])
                  socket.emit('setMoldNumberSuccess', doc1)
                  // process.exit(0)
                }
              })
            })
          }
        })
      }
    })
  })
  /*client.on('setMoldNumber', function (data) {
    console.log(data)
    var id = data._id
    var machineID = data.machineID
    var moldNum = data.moldNum

    MongoClient.connect(config.dbUrl + config.dbName).then(db => {
      var col = db.collection(machineID)

      // find the original record, because we need to get complete information for response
      col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
        if (err) {
          socket.emit('setMoldNumberFail', data)
        } else {
          if (docs.length === 0) {
            console.log('no data')
            data.moldNum = ''
            socket.emit('setMoldNumberFail', data)
          } else {
            var doc = docs[0]

            // notify the server that the order number is changed, and wait for product update
            col = db.collection(config.calHandleCommandColName)
            col.insertOne({
              id: id,
              machineID: machineID,
              moldNumber: moldNum,
              opcode: opcodes.set_moldNumber_opcode
            }).then(result => {
              // console.log(result)
              col = db.collection(machineID) */
/*
              var testFlag = true
              if (testFlag) { // for test
                col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
                  if (err) {
                    data.moldNum = ''
                    socket.emit('setMoldNumberFail', data)
                  } else {
                    if (docs.length === 0) {
                      console.log('no data')
                      data.moldNum = ''
                      socket.emit('setMoldNumberFail', data)
                    } else {
                      doc = docs[0]
                      doc['product'] = 'new product'
                      doc['moldArray'] = ['1', '2', '3']
                      doc['moldNum'] = moldNum
                      socket.emit('setMoldNumberSuccess', doc)
                      db.close()
                    }
                  }
                })
              }
*/
              /* var newMoldNum
              var timeout = 0

              // query the change per second
              var waitFunc = setInterval(function () {
                timeout++
                // doc['moldNum'] = moldNum

                // maximum wait 30 secs, if timeout, just reply the origin record
                if (timeout >= 5) {
                  clearInterval(waitFunc)
                  data.moldNum = doc.moldNum
                  socket.emit('setMoldNumberFail', data)
                  db.close()
                } else {
                  // query the record and judge the product has changed or not yet
                  col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
                    if (err) {
                      data.moldNum = ''
                      socket.emit('setMoldNumberFail', data)
                    } else {
                      if (docs.length === 0) {
                        console.log('no data')
                        data.moldNum = ''
                        socket.emit('setMoldNumberFail', data)
                      } else {
                        doc = docs[0]
                        newMoldNum = doc['moldNum']
                        if (newMoldNum !== undefined && newMoldNum === moldNum) {
                          clearInterval(waitFunc)
                          socket.emit('setMoldNumberSuccess', doc)
                          db.close()
                        }
                      }
                    }
                  })
                }
              }, 1000)
            })
          }
        }
      })
    }).catch(err => {
      if (err) {
        data.moldNum = ''
        socket.emit('setMoldNumberFail', data)
      }
    })
  }) */
  client.on('setWarehousingPeriodlyReport', function (data) {
    var id = data._id
    var machineID = data.machineID
    var warehousing = data.warehousing
    var product = data.product
    MongoClient.connect(config.dbUrl, function(err, client) {
      if (err) {
        socket.emit('setWarehousingFail', data)
      } else {
          client.db(config.dbName).collection(machineID).findOneAndUpdate({'_id': ObjectID(id)}, {$set: {'warehousing': warehousing}}, {returnOriginal: false}, function (err1, doc) {
          if (err1) {
            socket.emit('setWarehousingFail', data)
          } else {
            if (doc.value['warehousing'] === warehousing) {
              socket.emit('setWarehousingSuccess', doc)
            } else {
              socket.emit('setWarehousingFail', data)
            }
          }
        })
      }
    })
  })
  client.on('setBadNumPeriodlyReport', function (data) {
    var id = data._id
    var machineID = data.machineID
    var badNum = data.badNum
    var product = data.product
    MongoClient.connect(config.dbUrl, function(err, client) {
      if (err) {
        socket.emit('setBadNumFail', data)
        console.log('1')
      } else {
          client.db(config.dbName).collection(machineID).findOneAndUpdate({'_id': ObjectID(id)}, {$set: {'badNum': badNum}}, {returnOriginal: false}, function (err1, doc) {
          if (err1) {
            console.log('2')
            socket.emit('setBadNumFail', data)
          } else {
            console.log('3')
            console.log(doc.value)
            console.log(data)
            if (doc.value['badNum'] === badNum) {
              socket.emit('setBadNumSuccess', doc)
            } else {
              socket.emit('setBadNumFail', data)
            }
          }
        })
      }
    })
  })
  client.on('setWarehousing', function (data) {
    // console.log(data)
    var id = data._id
    var machineID = data.machineID
    var warehousing = data.warehousing
    var product = data.product

    MongoClient.connect(config.dbUrl + config.dbName).then(db => {
      var col = db.collection(machineID)

      // find the original record, because we need to get complete information for response
      col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
        if (err) {
          socket.emit('setWarehousingFail', data)
        } else {
          if (docs.length === 0) {
            console.log('no data')
            data.warehousing = ''
            socket.emit('setWarehousingFail', data)
          } else {
            var doc = docs[0]
            var newWarehousing

            // notify the server that the order number is changed, and wait for product update
            col = db.collection(config.calHandleCommandColName)
            col.insertOne({
              id: id,
              machineID: machineID,
              warehousing: warehousing,
              product: product,
              opcode: opcodes.set_warehousing_opcode
            }).then(result => {
              // console.log(result)
              col = db.collection(machineID)

              // var testFlag = true
              // if (testFlag) { // for test
              //   col.find({'_id': ObjectID(id)}).toArray(function (err, docs) {
              //     if (err) {
              //       data.warehousing = ''
              //       socket.emit('setWarehousingFail', data)
              //     } else {
              //       if (docs.length === 0) {
              //         console.log('no data')
              //         data.warehousing = ''
              //         socket.emit('setWarehousingFail', data)
              //       } else {
              //         doc = docs[0]
              //         doc['warehousing'] = warehousing
              //         doc['badNum'] = 100
              //         doc['badRate'] = '87%'
              //         socket.emit('setWarehousingSuccess', doc)
              //         db.close()
              //       }
              //     }
              //   })
              // }

              var timeout = 0

              // query the change per second
              var waitFunc = setInterval(function () {
                timeout++
                // doc['moldNum'] = moldNum

                // maximum wait 30 secs, if timeout, just reply the origin record
                if (timeout >= 5) {
                  clearInterval(waitFunc)
                  data.warehousing = doc.warehousing
                  socket.emit('setWarehousingFail', data)
                  db.close()
                } else {
                  // query the record and judge the product has changed or not yet
                  col.find({'product': product}).limit(1).toArray(function (err, docs) {
                    if (err) {
                      data.warehousing = ''
                      socket.emit('setWarehousingFail', data)
                    } else {
                      if (docs.length === 0) {
                        console.log('no data')
                        data.warehousing = ''
                        socket.emit('setWarehousingFail', data)
                      } else {
                        doc = docs[0]
                        newWarehousing = doc['warehousing']
                        if (newWarehousing !== undefined && newWarehousing === Number(warehousing)) {
                          clearInterval(waitFunc)
                          socket.emit('setWarehousingSuccess', doc)
                          db.close()
                        }
                      }
                    }
                  })
                }
              }, 1000)
            })
          }
        }
      })
    }).catch(err => {
      if (err) {
        data.moldNum = ''
        socket.emit('setWarehousingFail', data)
      }
    })
  })
})
